import React, { useState } from "react";
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity 
} from "react-native";

export default function App() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const API_KEY = "bdd4e71ffe22033d3f2d71c8d864c566"; // coloque sua chave aqui

  // Função que busca o clima da API
  const fetchWeather = async () => {
    if (!city) return;

    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&lang=pt_br&units=metric`
      );

      const data = await response.json();
      if (data.cod === "404") {
        setWeather({ error: "Cidade não encontrada" });
        return;
      }

      setWeather(data);
    } catch (error) {
      setWeather({ error: "Erro ao buscar dados" });
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Previsão do Tempo</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite a cidade"
        value={city}
        onChangeText={setCity}
      />

      <TouchableOpacity style={styles.button} onPress={fetchWeather}>
        <Text style={styles.buttonText}>Buscar</Text>
      </TouchableOpacity>

      {weather && (
        <View style={styles.box}>
          {weather.error ? (
            <Text style={styles.error}>{weather.error}</Text>
          ) : (
            <>
              <Text style={styles.city}>{weather.name}</Text>
              <Text style={styles.temp}>
                {Math.round(weather.main.temp)}°C
              </Text>
              <Text style={styles.description}>
                {weather.weather[0].description}
              </Text>
              <Text style={styles.icon}>
                {weather.weather[0].main === "Clear" && "☀️"}
                {weather.weather[0].main === "Clouds" && "☁️"}
                {weather.weather[0].main === "Rain" && "🌧️"}
                {weather.weather[0].main === "Snow" && "❄️"}
                {weather.weather[0].main === "Thunderstorm" && "⛈️"}
                {weather.weather[0].main === "Drizzle" && "🌦️"}
                {weather.weather[0].main === "Mist" && "🌫️"}
              </Text>
            </>
          )}
        </View>
      )}
    </View>
  );
}

// ESTILOS
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f2f2f2",
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 20,
  },
  input: {
    width: "80%",
    borderWidth: 1,
    borderColor: "#aaa",
    padding: 10,
    borderRadius: 8,
    backgroundColor: "#fff",
  },
  button: {
    width: "80%",
    marginTop: 10,
    backgroundColor: "#007bff",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  box: {
    marginTop: 20,
    padding: 20,
    backgroundColor: "#fff",
    width: "80%",
    borderRadius: 10,
    alignItems: "center",
    elevation: 3,
  },
  city: {
    fontSize: 24,
    fontWeight: "bold",
  },
  temp: {
    fontSize: 40,
    fontWeight: "bold",
    marginVertical: 10,
  },
  description: {
    fontSize: 18,
    textTransform: "capitalize",
  },
  icon: {
    fontSize: 60,
    marginTop: 10,
  },
  error: {
    color: "red",
    fontSize: 18,
  },
});
